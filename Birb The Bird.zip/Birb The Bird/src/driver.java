import bird.Bird;

import java.io.File;
import java.io.Flushable;
import java.io.IOException;
import java.util.Scanner;

public class driver {

    public static void main (String[] args) throws IOException{
        Bird[] allBird;
        allBird = createNewArray();
        processArrayOfBird(allBird);
        flyAway(allBird);
    }

    public static Bird[] createNewArray() throws IOException {

        String name;
        double height, weight;
        Boolean canFly;
        Bird aBird;

        File aFileCOunter = new File("bird.txt");
        Scanner inFileCounter  = new Scanner (aFileCOunter);
        int indexcounter = 0;
        while(inFileCounter.hasNextLine()){
            inFileCounter.nextLine();
           indexcounter++;
        }
        inFileCounter.close();

        Bird[] allBird = new Bird[indexcounter];

        File aFile = new File("bird.txt");
        Scanner inFile = new Scanner(aFile);
        int indexArray = 0;

        while(inFile.hasNext()){
            name = inFile.next();
            height = inFile.nextDouble();
            weight = inFile.nextDouble();
            canFly = inFile.nextBoolean();


            allBird[indexArray] = new Bird(name, height, weight, canFly);
            indexArray++;

        }
        inFile.close();
        return allBird;

    }

    public static void processArrayOfBird(Bird[] birds) throws IOException{

        //min height max weight max speed

        double minHeight = birds[0].getHeight();
        double maxWeight = birds[0].getWeight();
        double maxSpeed = birds[0].getSpeed();

        int indexHeight = 0;
        int indexWeight = 0;
        int indexSpeed = 0;


        for(int i = 0; i < birds.length; i++){

            double currHeight = birds[i].getHeight();
            double currWeight = birds[i].getWeight();
            double currSpeed = birds[i].getSpeed();


            if (currHeight < minHeight){
                minHeight = currHeight;
                indexHeight = i;
            }
            if(currWeight > maxWeight){
                maxWeight = currWeight;
                indexWeight = i;

            }
            if (currSpeed > maxSpeed){
                maxSpeed = currSpeed;
                indexSpeed = i;

            }



        }
        System.out.println(birds[indexHeight].getName() + " has the minimum height and all the info of that bird is " + birds[indexHeight]);
        System.out.println(birds[indexWeight].getName() + " has the maximum weight and all the info of that bird is " + birds[indexWeight]);
        System.out.println(birds[indexSpeed].getName() + " has the maximum speed and all the info of that bird is " + birds[indexSpeed]);

    }

        public static void flyAway(Bird[] flyingbirds){
        for(int i = 0; i < flyingbirds.length; i++){
            Boolean canFly = flyingbirds[i].getCanFly();
            if(canFly){
                System.out.println(flyingbirds[i].getName() + " can fly.");
            }
            else{
                System.out.println(flyingbirds[i].getName() + " cannot fly.");
            }
        }
        }

}
