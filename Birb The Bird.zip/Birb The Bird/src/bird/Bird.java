package bird;
import java.util.Random;
public class Bird {

    private String name;
    private double height;
    private double weight;
    private double speed;
    private Boolean canFly;

    public Bird(String name, double height, double weight, Boolean canFly) {
        this.name = name;
        this.height = height;
        this.weight = weight;
        Random myRan = new Random();
        speed = myRan.nextDouble(10,26);
        this.canFly = canFly;


    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public Boolean getCanFly() {
        return canFly;
    }

    public void setCanFly(Boolean canFly) {
        this.canFly = canFly;
    }

    @Override
    public String toString() {
        return "Bird{" +
                "name='" + name + '\'' +
                ", height=" + height +
                ", weight=" + weight +
                ", speed=" + speed +
                ", canFly=" + canFly +
                '}';
    }
}
